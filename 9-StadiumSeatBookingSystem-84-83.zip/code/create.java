// package com.seatbooking;

import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class create {

    public create() {
        JFrame frame = new JFrame("New Account");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.getContentPane().setLayout(null);

        JLabel mainlabel = new JLabel("Create New Account ");
        mainlabel.setFont(new Font("Verdana", Font.PLAIN, 18));
        mainlabel.setBounds(50, 20, 250, 25);
        frame.getContentPane().add(mainlabel);

        JLabel fullnamelabel = new JLabel("Name :");
        fullnamelabel.setBounds(10, 70, 80, 25);
        frame.getContentPane().add(fullnamelabel);

        JTextField fullnametext = new JTextField();
        fullnametext.setBounds(100, 70, 165, 25);
        frame.getContentPane().add(fullnametext);

        JLabel adminlabel = new JLabel("User name :");
        adminlabel.setBounds(10, 90, 80, 25);
        frame.getContentPane().add(adminlabel);

        JTextField admintext = new JTextField();
        admintext.setBounds(100, 90, 165, 25);
        frame.getContentPane().add(admintext);

        JLabel maillabel = new JLabel("Gmail :");
        maillabel.setBounds(10, 110, 80, 25);
        frame.getContentPane().add(maillabel);

        JTextField mailtext = new JTextField();
        mailtext.setBounds(100, 110, 165, 25);
        frame.getContentPane().add(mailtext);

        // [password label and text field
        JLabel passwordlabel = new JLabel("Password :");
        passwordlabel.setBounds(10, 130, 80, 25);
        frame.getContentPane().add(passwordlabel);

        JPasswordField passwordtext = new JPasswordField();
        passwordtext.setBounds(100, 130, 165, 25);
        frame.getContentPane().add(passwordtext);

        // message on pressing login button
        JLabel sucess = new JLabel();
        sucess.setBounds(275, 65, 80, 25);
        frame.getContentPane().add(sucess);

        JLabel sucess1 = new JLabel();
        sucess1.setBounds(275, 85, 80, 25);
        frame.getContentPane().add(sucess1);

        JLabel sucess2 = new JLabel();
        sucess2.setBounds(275, 105, 100, 25);
        frame.getContentPane().add(sucess2);

        JLabel sucess3 = new JLabel();
        sucess3.setBounds(275, 125, 80, 25);
        frame.getContentPane().add(sucess3);

        JButton create_account = new JButton("Create account");
        create_account.setBounds(120, 200, 120, 25);
        create_account.setBorder(BorderFactory.createRaisedBevelBorder());
        create_account.setFocusable(false);
        frame.getContentPane().add(create_account);
        create_account.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user = admintext.getText();
                String password = passwordtext.getText();
                String name = fullnametext.getText();
                String mail = mailtext.getText();

                System.out.println(user + "," + password);
                if (name.length() < 2) {
                    sucess.setText("Invalid input");
                }
                if (user.length() < 5) {
                    sucess1.setText("Invalid user");
                }
                if (password.length() < 5) {
                    sucess2.setText("Invalid password");
                }
                if (mail.length() < 15) {
                    sucess3.setText("Invalid mail");
                }

                if (name.length() >= 5 && password.length() >= 5 && user.length() >= 5 && mail.length() >= 15) {
                    try {
                        FileWriter fw = new FileWriter("login.txt", true);
                        FileWriter fw1 = new FileWriter("User_pass.txt", true);
                        fw.write(user + "\t" + password + "\t" + name + "\t" + mail + "\n");
                        fw1.write(user + "\t" + password + "\n");
                        fw1.close();
                        fw.close();
                        frame.setVisible(false);
                        JOptionPane.showMessageDialog(create_account, "Registration completed");

                        new userlogin();
                    } catch (IOException e1) {
                        // TODO Auto-generated catch block
                        e1.printStackTrace();
                    }
                }

                // sucess.setText("please fill all details");

            }
        });

        // back button
        JButton back = new JButton("Back");
        back.setBounds(300, 240, 70, 20);
        back.setBorder(BorderFactory.createRaisedBevelBorder());
        back.setFocusable(false);

        frame.getContentPane().add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new userlogin();
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new create();
    }
}
