// import javax.swing.*;
// import java.awt.Font;
// import java.awt.event.ActionEvent;
// import java.awt.event.ActionListener;

// public class payment {

// public payment() {
// JFrame frame = new JFrame("Window1");
// frame.setSize(360, 300);
// frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

// frame.getContentPane().setLayout(null);

// JLabel mainlabel = new JLabel("Select Payment method ");
// mainlabel.setFont(new Font("Verdana", Font.PLAIN, 18));
// mainlabel.setBounds(70, 20, 250, 25);
// frame.getContentPane().add(mainlabel);

// JButton Debit = new JButton("Debit card ");
// Debit.setBounds(65, 80, 100, 40);
// Debit.setBorder(BorderFactory.createRaisedBevelBorder());
// Debit.setFocusable(false);
// frame.getContentPane().add(Debit);

// JTextField paytext = new JTextField();
// paytext.setBounds(100, 130, 165, 25);
// frame.getContentPane().add(paytext);

// Debit.addActionListener(new ActionListener() {
// @Override
// public void actionPerformed(ActionEvent e) {
// frame.setVisible(false);
// new normal();
// }
// });

// // Ring side seat
// JButton credit = new JButton("Credit card");
// credit.setBounds(185, 80, 100, 40);
// credit.setBorder(BorderFactory.createRaisedBevelBorder());
// credit.setFocusable(false);
// frame.getContentPane().add(credit);
// credit.addActionListener(new ActionListener() {
// @Override
// public void actionPerformed(ActionEvent e) {
// frame.setVisible(false);

// }
// });

// frame.setVisible(true);
// }

// public static void main(String[] args) {
// new payment();
// }
// }
