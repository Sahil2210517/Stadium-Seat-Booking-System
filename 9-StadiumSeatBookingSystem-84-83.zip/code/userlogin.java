// package com.seatbooking;

import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.Buffer;

public class userlogin {
    public static void main(String[] args) {
        new userlogin();
    }

    public userlogin() {

        JFrame frame = new JFrame("Main window");
        frame.setSize(350, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.getContentPane().setLayout(null);

        JLabel mainlabel = new JLabel("Stadium Seat Booking System ");
        mainlabel.setFont(new Font("Verdana", Font.PLAIN, 18));
        mainlabel.setBounds(25, 20, 300, 25);
        frame.getContentPane().add(mainlabel);

        JLabel adminlabel = new JLabel("User name");
        adminlabel.setBounds(25, 70, 80, 25);
        frame.getContentPane().add(adminlabel);

        JTextField admintext = new JTextField();
        admintext.setBounds(115, 70, 165, 25);
        frame.getContentPane().add(admintext);

        // [password label and text field
        JLabel passwordlabel = new JLabel("Password");
        passwordlabel.setBounds(25, 100, 80, 25);
        frame.getContentPane().add(passwordlabel);

        JPasswordField passwordtext = new JPasswordField();
        passwordtext.setBounds(115, 100, 165, 25);
        frame.getContentPane().add(passwordtext);

        // message on pressing login button
        JLabel sucess = new JLabel("");
        sucess.setBounds(95, 140, 300, 25);
        frame.getContentPane().add(sucess);
        sucess.setText("");

        // login button
        JButton login = new JButton("Login");
        login.setBounds(35, 170, 80, 25);
        login.setBorder(BorderFactory.createRaisedBevelBorder());
        login.setFocusable(false);
        frame.getContentPane().add(login);
        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean match = false;
                String user = admintext.getText();
                String password = passwordtext.getText().toString();

                try (FileReader fr = new FileReader("User_pass.txt")) {
                    BufferedReader br = new BufferedReader(fr);
                    String line;
                    Object str;
                    while ((str = br.readLine()) != null) {
                        if (str.equals(user + "\t" + password)) {
                            match = true;
                            break;
                        }
                    }
                    if (match) {
                        frame.setVisible(false);
                        new seattype();
                    } else {
                        sucess.setText("Invalid username or password!");
                    }
                    fr.close();
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
                // System.out.println(user + "," + password);
            }
        });

        // or label
        JLabel or = new JLabel("Or");
        or.setBounds(135, 170, 30, 25);
        frame.getContentPane().add(or);

        // create account button
        JButton create_account = new JButton("Create account");
        create_account.setBounds(165, 170, 120, 25);
        create_account.setBorder(BorderFactory.createRaisedBevelBorder());
        create_account.setFocusable(false);
        frame.getContentPane().add(create_account);
        create_account.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new create();
            }
        });

        // back button
        JButton back = new JButton("Back");
        back.setBounds(215, 230, 70, 20);
        back.setBorder(BorderFactory.createRaisedBevelBorder());
        back.setFocusable(false);

        frame.getContentPane().add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                // mainwindow w1 = new mainwindow();
                // mainwindow.showwindow();
            }
        });

        frame.setVisible(true);
    }

    protected static void setVisible(boolean b) {
    }
}