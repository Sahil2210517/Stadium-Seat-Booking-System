// package com.seatbooking;

import javax.swing.*;

import com.toedter.calendar.JDateChooser;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.util.Random;

public class endstand {
    public int a = 100;
    JDateChooser dateChooser = new JDateChooser();

    public String seatNo() {
        Random random = new Random();
        int a = random.nextInt(100);
        return String.valueOf(a);
    }

    public endstand() {
        JPanel date = new JPanel();
        date.setBounds(130, 110, 80, 45);
        date.add(dateChooser);

        JFrame frame = new JFrame("End Stand seat");
        frame.setSize(360, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(date);

        frame.getContentPane().setLayout(null);

        JLabel mainlabel = new JLabel("End Stand Seat Booking ");
        mainlabel.setFont(new Font("Verdana", Font.PLAIN, 18));
        mainlabel.setBounds(70, 20, 250, 25);
        frame.getContentPane().add(mainlabel);

        JLabel seatlabel = new JLabel("Seats Available : ");
        seatlabel.setBounds(10, 70, 150, 25);
        frame.getContentPane().add(seatlabel);

        JLabel seatnolabel = new JLabel(String.valueOf(a));
        seatnolabel.setBounds(130, 70, 50, 25);
        frame.getContentPane().add(seatnolabel);

        JLabel pricelabel = new JLabel("Price                   :      2000");
        pricelabel.setBounds(10, 90, 250, 25);
        frame.getContentPane().add(pricelabel);

        JLabel datelabel = new JLabel("Date Of Game   : ");
        datelabel.setBounds(10, 110, 150, 25);
        frame.getContentPane().add(datelabel);

        // book now
        JButton bookbutton = new JButton("Book Now ");
        bookbutton.setBounds(130, 160, 100, 25);
        bookbutton.setBorder(BorderFactory.createRaisedBevelBorder());
        bookbutton.setFocusable(false);
        frame.getContentPane().add(bookbutton);

        bookbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (dateChooser.getDate() == null) {
                    JOptionPane.showMessageDialog(null, "PLEASE CHOOSE A DATE");
                } else {
                    String strDate = DateFormat.getDateInstance().format(dateChooser.getDate());
                    JOptionPane.showMessageDialog(null, "TICKETS BOOKED SUCCESSFULLY!");
                    JOptionPane.showMessageDialog(null, "MATCH IS ON: " + strDate + " & YOUR SEATNO IS: " + seatNo());
                    a--;
                    String a1 = String.valueOf(a);
                    seatnolabel.setText(a1);
                    frame.setVisible(false);
                    new seattype();
                }
            }
        });

        JButton back = new JButton("Home");
        back.setBounds(260, 170, 70, 20);
        back.setBorder(BorderFactory.createRaisedBevelBorder());
        back.setFocusable(false);

        frame.getContentPane().add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new seattype();
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new endstand();
    }

}
