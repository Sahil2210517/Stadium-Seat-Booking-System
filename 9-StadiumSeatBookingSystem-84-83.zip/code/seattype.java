// package com.seatbooking;

import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class seattype {

    public seattype() {
        JFrame frame = new JFrame("Window1");
        frame.setSize(360, 250);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.getContentPane().setLayout(null);

        JLabel mainlabel = new JLabel("Select seat Category ");
        mainlabel.setFont(new Font("Verdana", Font.PLAIN, 18));
        mainlabel.setBounds(70, 20, 250, 25);
        frame.getContentPane().add(mainlabel);

        // normal seat
        JButton Normalbutton = new JButton("Normal ");
        Normalbutton.setBounds(10, 80, 100, 40);
        Normalbutton.setBorder(BorderFactory.createRaisedBevelBorder());
        Normalbutton.setFocusable(false);
        frame.getContentPane().add(Normalbutton);

        Normalbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new normal();
            }
        });

        // Ring side seat
        JButton Ringsidebutton = new JButton("Ring Side");
        Ringsidebutton.setBounds(120, 80, 100, 40);
        Ringsidebutton.setBorder(BorderFactory.createRaisedBevelBorder());
        Ringsidebutton.setFocusable(false);
        frame.getContentPane().add(Ringsidebutton);
        Ringsidebutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new ring();
            }
        });

        // End Stand
        JButton Endstandbutton = new JButton("End Stand");
        Endstandbutton.setBounds(230, 80, 100, 40);
        Endstandbutton.setBorder(BorderFactory.createRaisedBevelBorder());
        Endstandbutton.setFocusable(false);
        frame.getContentPane().add(Endstandbutton);
        Endstandbutton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new endstand();
            }
        });

        JButton back = new JButton("Back");
        back.setBounds(260, 170, 70, 20);
        back.setBorder(BorderFactory.createRaisedBevelBorder());
        back.setFocusable(false);

        frame.getContentPane().add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.setVisible(false);
                new userlogin();
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new seattype();
    }
}
