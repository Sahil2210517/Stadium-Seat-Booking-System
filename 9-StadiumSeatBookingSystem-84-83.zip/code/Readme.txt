To Run the program follow these steps:
1-Run the userlogin.java file
2- if new user click on create account and create a new account other wise enter username and password to login .
3- after login select the type of seat.
4-After selecting the seat type a pop window will appear and then select the date for booking ang click booknow.
5- a pop window will appeaar which will display the date and the seat no.
6-End.
